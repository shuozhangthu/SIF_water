%% Load data

load('figure1_data.mat')
addpath('m_map');  % Add mapping toolbox path

% Prepare geographic coordinates
lons = -180+0.125:0.25:180-0.125;
lats = 90-0.125:-0.25:30+0.125;
[area_lons, area_lats] = meshgrid(lons, lats);
coast = load('coast.mat');
ncx = coast.long;
ncy = coast.lat;

% Projection transformation
m_proj('stereographic','latitude',90,'radius',60,'rotangle',0);
[x,y] = m_ll2xy(area_lons, area_lats);
[ncxx,ncyy] = m_ll2xy(ncx, ncy);

% Fit analysis
distance = -42.5:5:37.5;

% Negative distance fit
idx_neg = distance < 0;
p_neg = polyfit(distance(idx_neg), SIF_north(idx_neg), 1);
fitLine_neg = polyval(p_neg, distance(idx_neg));
[r_neg, pval_neg] = corr(distance(idx_neg)', SIF_north(idx_neg), 'Rows', 'complete');

% Positive distance fit
idx_pos = distance > -2;
p_pos = polyfit(distance(idx_pos), SIF_north(idx_pos), 1);
fitLine_pos = polyval(p_pos, distance(idx_pos));
[r_pos, pval_pos] = corr(distance(idx_pos)', SIF_north(idx_pos), 'Rows', 'complete');

%% Create figure
fig = figure();
set(gcf,'position',[400,300,700,400], 'Color', 'w');

%% Subplot 1: Spatial Distribution
ax1 = subplot(1,2,1);
pcolor(x,y, delta_doy_mean); 
shading flat;
hold on;
m_grid('xtick',-180:45:180,'ytick',0:10:80,'YTicklabel',[],...
    'FontName','Arial','Fontsize',11,'LineWidth',1);
plot(ncxx,ncyy,'LineWidth',1,'Color','[0 0 0]');
colormap(ax1,color_NCV_blu_red);
caxis([-40 40]);
text(0,1,'(a)','Units','normalized','Fontsize',14,'Fontweight','bold','FontName','Arial');

c = colorbar('south','Position',[0.4 0.15 0.25 0.02], ...
    'FontName','Arial','FontSize',10,'TickLength',0.04,'LineWidth',0.8);
c.AxisLocation = 'in';
c.LineWidth = 0.8;
c.Ticks = -40:20:40;
c.Label.String = '\DeltaDOY_{SIF,PAR}(day)';

%% Subplot 2: Statistical Relationship
ax2 = subplot(1,2,2);
cmap = color_NCV_blu_red;
colorIdx = round(linspace(1, length(cmap), length(distance)));

plot(distance(idx_neg), fitLine_neg, 'b--', 'LineWidth', 1.2);
hold on;
plot(distance(idx_pos), fitLine_pos, 'r--', 'LineWidth', 1.2);

text(0.2, 0.7, sprintf('r = %.2f\np = %.3f', r_neg, pval_neg),...
    'Units','normalized', 'FontSize', 11);
text(0.45, 0.1, 'W constrained','Units','normalized', 'FontSize', 11);
text(0.8, 0.7, sprintf('r = %.2f\np = %.3f', r_pos, pval_pos),...
    'Units','normalized', 'FontSize', 11);
text(0.55, 0.1, 'T constrained','Units','normalized', 'FontSize', 11);

for i = 1:length(distance)
    h = errorbar(distance(i)+2.5, SIF_north(i), ...
        SIF_north(i) - SIF_north_ci_lower(i), ...
        SIF_north_ci_upper(i) - SIF_north(i),...
        'o', 'MarkerSize', 8, 'MarkerFaceColor', cmap(colorIdx(i), :), ...
        'Color', [0 0 0], 'CapSize', 10, 'LineWidth', 1);
end

xline(0,'LineWidth',1,'Color',[0 0 0],'LineStyle',':');
text(0,1,'(b)','Units','normalized','Fontsize',14,'Fontweight','bold','FontName','Arial');

xlim([-44 44]); xticks(-40:20:40);
set(gca,'XTickLabel',{'-40','-20','0','20','40'}, 'FontSize', 11);
ylim([0.44 0.57]);
ylabel('Normalized SIF_{max}', 'FontSize', 11);
xlabel('\DeltaDOY_{SIF,PAR}(day)', 'FontSize', 11);
box on; set(gca,'linewidth',1, 'Box', 'on', 'Layer', 'top');