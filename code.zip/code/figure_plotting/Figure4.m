%% Load data

load('figure4_data.mat'); 
addpath('m_map');  % Add mapping toolbox path

% Prepare geographic coordinates
lons = -180+0.125:0.25:180-0.125;
lats = 90-0.125:-0.25:30+0.125;
[area_lons, area_lats] = meshgrid(lons, lats);
coast = load('coast.mat');
ncx = coast.long;
ncy = coast.lat;

% Projection transformation
m_proj('stereographic','latitude',90,'radius',60,'rotangle',0);
[x,y] = m_ll2xy(area_lons, area_lats);
[ncxx,ncyy] = m_ll2xy(ncx, ncy);

% Color scheme for visualization
color_palette = struct(...
    'scenario', struct(...
        'ssp245', [34 54 255]/255, ...   % Blue
        'ssp585', [226 0 16]/255), ...   % Red
    'time_periods', [210 210 210;        % Gray
                     255 200 90;         % Light orange
                     255 150 30;         % Medium orange
                     255 100 0;          % Dark orange
                     223 51 47]/255);    % Red
%% Statistical Calculations
years = 2016:2100;
% Calculate mean and standard deviation for both scenarios
ssp585_stats = struct(...
    'mean', nanmean(ssp585(1:85, :) * 100, 2), ...
    'std', nanstd(ssp585(1:85, :) * 100, [], 2));

ssp245_stats = struct(...
    'mean', nanmean(ssp245(1:85, :) * 100, 2), ...
    'std', nanstd(ssp245(1:85, :) * 100, [], 2));

%% Create figure

fig = figure('Position', [400, 300, 700, 550], 'Color', 'w');

plot_format = {'FontName', 'Arial', 'Fontsize', 11, 'LineWidth', 1};
text_format = {'Units', 'normalized', 'FontName', 'Arial', 'Fontweight', 'bold'};

%% Subplot 1: SSP245 Spatial Pattern
ax1 = subplot_tight(2, 2, 1, 0.06, 0.06, 0.01, -0.025);
pcolor(x, y, cond_ssp245); 
shading flat;
hold on;
m_grid('xtick', -180:45:180, 'ytick', 0:10:80, 'YTicklabel', [], plot_format{:});
plot(ncxx, ncyy, 'LineWidth', 1, 'Color', 'k');
colormap(ax1, color_palette.time_periods);
text(0.03, 1, '(a)', text_format{:}, 'Fontsize', 14);
text(0.36, 0.9, 'SSP245', plot_format{:});

%% Subplot 2: SSP585 Spatial Pattern
ax2 = subplot_tight(2, 2, 2, 0.06, 0.06, 0.03, -0.025);
pcolor(x, y, cond_ssp585); 
shading flat;
hold on;
m_grid('xtick', -180:45:180, 'ytick', 0:10:80, 'YTicklabel', [], plot_format{:});
plot(ncxx, ncyy, 'LineWidth', 1, 'Color', 'k');
colormap(ax2, color_palette.time_periods);
text(0.03, 1, '(b)', text_format{:}, 'Fontsize', 14);
text(0.36, 0.9, 'SSP585', plot_format{:});

% Shared colorbar for spatial patterns
c = colorbar('Ticks', 0.4:4/5:4.5, ...
             'TickLabels', {'T constrained', '2010s', '2030s', '2060s', '2090s'}, ...
             'FontName', 'Arial', 'FontSize', 10, 'TickLength', 0.001);
c.LineWidth = 0.8;

%% Subplot 3: Temporal Trends
ax3 = subplot_tight(2, 2, [3,4], 0.06, 0.06, 0.01, 0);

% Plot confidence intervals
fill([years, fliplr(years)], ...
     [(ssp245_stats.mean-ssp245_stats.std)', fliplr((ssp245_stats.mean+ssp245_stats.std)')], ...
     color_palette.scenario.ssp245, 'edgealpha', 0, 'facealpha', 0.2);
hold on;
fill([years, fliplr(years)], ...
     [(ssp585_stats.mean-ssp585_stats.std)', fliplr((ssp585_stats.mean+ssp585_stats.std)')], ...
     color_palette.scenario.ssp585, 'edgealpha', 0, 'facealpha', 0.2);

% Plot mean trends
p1 = plot(years, ssp245_stats.mean, 'linewidth', 1.5, 'color', color_palette.scenario.ssp245);
p2 = plot(years, ssp585_stats.mean, 'linewidth', 1.5, 'color', color_palette.scenario.ssp585);

% Format plot
box on; set(gca, 'LineWidth', 1);
legend([p1 p2], {'SSP245', 'SSP585'}, 'Location', 'best');
set(gca, 'XLim', [2016 2100], 'XTick', 2010:10:2100, plot_format{:});
set(gca, 'YLim', [23 64], 'YTick', 0:10:100, plot_format{:});
xlabel('Year', plot_format{:});
ylabel('W constrained region (%)', plot_format{:});
text(0, 1.07, '(c)', text_format{:}, 'Fontsize', 14);