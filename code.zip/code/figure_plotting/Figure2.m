%% Load data

load('figure2_data.mat');
addpath('m_map');  % Add mapping toolbox path

% Prepare geographic coordinates
lon = -180+0.125:0.25:180-0.125;
lat = 90-0.125:-0.25:30+0.125;
[grid_lon, grid_lat] = meshgrid(lon, lat);
coastline = load('coast.mat');

% Projection transformation
m_proj('stereographic', 'latitude', 90, 'radius', 60, 'rotangle', 0);
[proj_x, proj_y] = m_ll2xy(grid_lon, grid_lat);
[coast_x, coast_y] = m_ll2xy(coastline.long, coastline.lat);

%% Create figure
fig = figure('Position', [400, 100, 700, 700], 'Color', 'w');

% Color scheme
colors = struct(...
    'blue', [34 54 255]/255, ...
    'lightBlue', [150 195 216]/255, ...
    'red', [226 0 16]/255, ...
    'lightRed', [227 146 142]/255, ...
    'gray', [145 147 151]/255);

%% Subplot 1: Trend Map
ax1 = subplot(2, 2, 1);
plot_North(trend_DOY_SIF_PAR, color_NCV_blu_red, '');
caxis([-0.8 0.8]);
addTextLabel(ax1, '(a)');

% Add colorbar
cb1 = colorbar('east', 'Position', [0.3 0.55 0.01 0.25], ...
    'FontName', 'Arial', 'FontSize', 10, 'TickLength', 0.036);
cb1.LineWidth = 0.8;
cb1.Label.String = 'days year^{-1}';

%% Subplot 2: Change Pattern Map
ax2 = subplot(2, 2, 2);
% Define change patterns
changePattern = nan(size(delta_2001_2005));
changePattern(delta_2001_2005>0 & delta_2016_2020>0) = 1;
changePattern(delta_2001_2005>0 & delta_2016_2020<0) = 2;
changePattern(delta_2001_2005<0 & delta_2016_2020>0) = 3;
changePattern(delta_2001_2005<0 & delta_2016_2020<0) = 4;

patternColors = [colors.lightRed; colors.red; colors.blue; colors.lightBlue];
plot_North(changePattern, patternColors, '');
addTextLabel(ax2, '(b)');

% Add categorical colorbar
cb2 = colorbar('Ticks', 1:4, 'TickLabels', {'W', 'T', 'T->W', 'W->T'}, ...
    'FontSize', 10, 'TickLength', 0.001, 'Position', [0.8 0.55 0.01 0.25]);
cb2.LineWidth = 0.8;

%% Subplot 3: Time Series
ax3 = subplot(2, 2, 3);
years = 2001:2020;

% Plot temperature-constrained data
plotTimeSeries_Significance(ax3, years, DOY_SIF_PAR_TEM, colors.red, 'T constrained');
% Plot precipitation-constrained data
plotTimeSeries_InSignificance(ax3, years, DOY_SIF_PAR_PRE, colors.blue, 'W constrained');

% Set axes properties
set(gca, 'XLim', [2000 2021], 'XTick', 2000:5:2020, ...
    'YLim', [-20 25], 'YTick', -20:10:25, ...
    'FontName', 'Arial', 'FontSize', 11, 'LineWidth', 1);

addTextLabel(ax3, '(c)');
xlabel('Year', 'FontSize', 11);
ylabel('\DeltaDOY_{SIF,PAR}(day)', 'FontSize', 11);

%% Subplot 4: SIFmax Time Series
ax4 = subplot(2, 2, 4);
% Left Y-axis - temperature constrained
plotSIFSeries(ax4, years, SIF_max_TEM, SIF_max_loess_filter_TEM, CI95_TEM, ...
    colors.red, 'left', 'SIF_{max}(mW m^{-2}nm^{-1}sr^{-1})');
% Right Y-axis - precipitation constrained
plotSIFSeries(ax4, years, SIF_max_PRE, SIF_max_loess_filter_PRE, CI95_PRE, ...
    colors.blue, 'right', '');

slope_TEM = Theil_Sen_Regress(years', SIF_max_TEM);
slope_PRE = Theil_Sen_Regress(years', SIF_max_PRE);

text(0.03, 0.87, ...
    sprintf('W constrained:\n%s×10^{-4} mW m^{-2} nm^{-1} sr^{-1} year^{-1}, p<0.01', ...
    num2str(round(slope_PRE*10000, -2))), ...
    'color', colors.blue, 'FontSize', 10, 'Units', 'normalized');

text(0.03, 0.14, ...
    sprintf('T constrained:\n%s×10^{-4} mW m^{-2} nm^{-1} sr^{-1} year^{-1}, p<0.01', ...
    num2str(round(slope_TEM*10000, -2))), ...
    'color', colors.red, 'FontSize', 10, 'Units', 'normalized');

addTextLabel(ax4, '(d)');
xlabel('Year', 'FontSize', 11);
box on; set(gca, 'LineWidth', 1);

%% Functions
function addTextLabel(ax, label)
    text(ax, 0, 1, label, 'Units', 'normalized', ...
        'Fontsize', 14, 'Fontweight', 'bold', 'FontName', 'Arial');
end

function plotTimeSeries_Significance(ax, x, y, color, label)
    hold(ax, 'on');
    box(ax, 'on');
    set(ax, 'LineWidth', 1);
    
    % Plot data points and line
    plot(ax, x, y, '-o', 'linewidth', 1.2, 'color', color);
    
    % Linear regression
    mdl = fitlm(x, y);
    slope = table2array(mdl.Coefficients(2, 1));
    intercept = table2array(mdl.Coefficients(1, 1));
    p_value = table2array(mdl.Coefficients(2, 4));
    
    % Plot regression line
    plot(ax, x, x*slope + intercept, 'linestyle', '-', 'linewidth', 1.2, 'color', color);
    
    % Add trend label
    text(ax, 0.03, 0.52 - (strcmp(label(1), 'W')*0.11), ...
        sprintf('%s: %.2f days year^{-1}, p=%s', ...
        label, slope, formatPValue(p_value)), ...
        'Units', 'normalized', 'FontSize', 10.5, 'color', color);
end

function plotTimeSeries_InSignificance(ax, x, y, color, label)
    hold(ax, 'on');
    box(ax, 'on');
    set(ax, 'LineWidth', 1);
    
    % Plot data points and line
    plot(ax, x, y, '-o', 'linewidth', 1.2, 'color', color);
    
    % Linear regression
    mdl = fitlm(x, y);
    slope = table2array(mdl.Coefficients(2, 1));
    intercept = table2array(mdl.Coefficients(1, 1));
    p_value = table2array(mdl.Coefficients(2, 4));
    
    % Plot regression line (dashed for non-significant)
    plot(ax, x, x*slope + intercept, 'linestyle', '--', 'linewidth', 1.2, 'color', color);
    
    % Add trend label
    text(ax, 0.03, 0.52 - (strcmp(label(1), 'W')*0.11), ...
        sprintf('%s: %.2f days year^{-1}, p=%s', ...
        label, slope, formatPValue(p_value)), ...
        'Units', 'normalized', 'FontSize', 10.5, 'color', color);
end

function plotSIFSeries(ax, x, y, y_fit, y_ci, color, yside, ylabelText)
    yyaxis(ax, yside);
    
    % Plot raw data and fitted line
    plot(ax, x, y, 'linewidth', 1, 'color', color);
    hold(ax, 'on');
    plot(ax, x, y_fit, 'linestyle', '-', 'linewidth', 2, 'color', color);
    
    % Plot confidence intervals
    fill(ax, [x, fliplr(x)], [(y_fit + y_ci)', fliplr((y_fit - y_ci)')], ...
        color, 'edgealpha', 0, 'facealpha', 0.4);
    
    % Set axis properties
    xlim(ax, [2000 2021]);
    set(ax, 'FontName', 'Arial', 'Fontsize', 11, 'YTickLabelRotation', 90);
    
    % Add Y-axis label if provided
    if ~isempty(ylabelText)
        ylabel(ax, ylabelText, 'color', [0 0 0], 'FontName', 'Arial', 'FontSize', 11);
    end
    
    % Set Y-axis limits based on side
    if strcmp(yside, 'left')
        ylim(ax, [0.115-0.0015, 0.115+0.012+0.0015 * 3]);
        yticks(ax, [0.115 0.120 0.125 0.13]);
    else
        ylim(ax, [0.06-0.0015, 0.06+0.012+0.0015 * 3]);
        yticks(ax, [0.06 0.065 0.07 0.075]);
    end
end

function p_str = formatPValue(p)
    % Format p-value for display
    if p < 0.01
        p_str = '<0.01';
    else
        p_str = sprintf('=%.2f', p);
    end
end