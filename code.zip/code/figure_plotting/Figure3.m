%% Load data

load('figure3_data.mat');

% Figure settings
width = 0.1;
left = 0;
top = 00;
cb_h = 0.8;
cb_w = 0.01;

%% Create figure

fig = figure('Position', [400, 300, 700, 300], 'Color', 'w');

%% Subplot 1: Climate Space Analysis
ax1 = subplot_tight(1,2,1, width, width, -left/2 * 0, top/2);

% Create temperature-precipitation grid
resolution = 200;
temperatureRange = linspace(30, -20, resolution);
precipitationRange = linspace(0, 3000, resolution);
[Range_prec, Range_temp] = meshgrid(precipitationRange, temperatureRange);

% Plot climate space
pcolor(Range_prec, Range_temp, Delta_SIF_PAR_mean);
shading flat
colormap(ax1, color_NCV_blu_red)
caxis([-40 40])
hold on

% Plot overall trend line
plot([0,2500], ([0,2500]*0.0046 + 3.7687), 'linewidth', 2, 'color', 'k') 

% Format axes
box on; set(gca,'LineWidth', 1)
xlim([0 3000])
ylim([-25 35])
xlabel('Mean annual precipitation (mm)', 'FontName', 'Arial', 'Fontsize', 11)
ylabel('Mean annual temperature (\circC)', 'FontName', 'Arial', 'Fontsize', 11)

% Add colorbar
c = colorbar('east', 'Position', [0.5 0.15 0.01 0.65], ...
    'FontName', 'Arial', 'FontSize', 10, 'TickLength', 0.0335);
c.LineWidth = 0.8;
c.Label.String = '\DeltaDOY_{SIF,PAR}(day)';

% Add subplot label
text(0, 1.06, '(a)', 'Units', 'normalized', 'Fontsize', 14, ...
    'Fontweight', 'bold', 'FontName', 'Arial');
set(gca, 'FontName', 'Arial', 'Fontsize', 11);
xticks([0 600 1200 1800 2400 3000])

%% Subplot 2: Vegetation Type Analysis
ax2 = subplot_tight(1,2,2, width, width, -left/2 * 0, top/2);
hold on

% Plot error bars for vegetation types
for i = 1:10   
    e = errorbar(prec_veg(i), temp_veg(i)*(500/38 * 3), ...
        temp_veg_std(i)*(500/38 * 3), temp_veg_std(i)*(500/38 * 3), ...
        prec_veg_std(i), prec_veg_std(i), ...
        "o", "MarkerSize", 1, ...
        "MarkerEdgeColor", "none", "MarkerFaceColor", [0.8 0.8 0.8]);
    e.Color = [0.7 0.7 0.7];
    e.LineWidth = 0.8;
end
box on; set(gca, 'LineWidth', 1)

% Vegetation type settings
NAME = {'ENF','EBF','DNF','DBF','MF','CSH','OSH','WSA','SAV','GRA'};
MARK = ["o","square","diamond","^","v","o","square","diamond","^","v"];
w_fill = 'filled';

% Plot vegetation type markers and vectors
for i = 1:10
    % Plot vector
    q = quiver(X(i,1), Y(i,1), U(i,1), V(i,1), 'MaxHeadSize', 1500);
    q.LineWidth = 1.5;
    
    % Calculate color indices
    iii = 10 - ceil((V_color(i,1)/40)*5 + 5);
    jjj = ceil((U_color(i,1)/40)*5 + 5);
    
    % Ensure indices are within bounds
    iii = min(max(iii, 1), 10);
    jjj = min(max(jjj, 1), 10);
    
    % Set marker color
    s_Color = [R(iii,jjj), G(iii,jjj), B(iii,jjj)]/255;
    
    % Plot marker
    eval(['s', num2str(i), ' = scatter(X(i), Y(i), 50, s_Color, w_fill, MARK(i));'])
    
    % Set vector color
    q.Color = [R(iii,jjj), G(iii,jjj), B(iii,jjj)]/255;
end

% Plot reference line
hold on
plot([150,1350], ([150,1350]*0.0046 + 3.7687)*1500/38, 'linewidth', 2, 'color', 'k')

% Format axes
text(0, 1.06, '(b)', 'Units', 'normalized', 'Fontsize', 14, ...
    'Fontweight', 'bold', 'FontName', 'Arial');
ylim([-225 * 3 310 * 3])
yticks([-20*(1500/38) -10*(1500/38) 0 10*(1500/38) 20*(1500/38) 30*(1500/38)])
yticklabels({'-20','-10','0','10','20','30'})
xticks([0 300 600 900 1200 1500])
set(gca, 'XLim', [0 1500], 'XTick', 0:300:1500, ...
    'FontName', 'Arial', 'Fontsize', 11);

xlabel('Mean annual precipitation (mm)', 'FontName', 'Arial', 'Fontsize', 11)
ylabel('Mean annual temperature (\circC)', 'FontName', 'Arial', 'Fontsize', 11)
