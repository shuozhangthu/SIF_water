function plot_North(plot_data, mycolor, titles)

ax = gca;

lons = -180+0.125:0.25:180-0.125;
lats = 90-0.125:-0.25:30+0.125;
for ii = 1:240
    area_lons(ii,:) = lons;
end
for jj = 1:1440
    area_lats(:,jj) = lats;
end
coast = load('coast.mat');
ncx = coast.long;
ncy = coast.lat;
clear lons lats ii jj
m_proj('stereographic','latitude',90,'radius',60,'rotagnle',0);
[x,y] = m_ll2xy(area_lons, area_lats);
[ncxx,ncyy] = m_ll2xy(ncx, ncy);

pcolor(x,y, plot_data);shading flat
hold on
m_grid('xtick',-180:45:180,'ytick',0:10:80,'YTicklabel',[],'Fontsize',11,'LineWidth',1);
plot(ncxx,ncyy,'LineWidth',1,'Color','[0 0 0]')
colormap(ax, mycolor)

% 使用text函数添加自定义标题，确保它显示在图层最上方
text(0.5, 1.13, titles, 'HorizontalAlignment', 'center', 'Units', 'normalized', 'FontSize', 12,'FontWeight','bold');

end